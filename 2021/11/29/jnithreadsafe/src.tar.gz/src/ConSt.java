public class ConSt {
  public ConSt() {
    mInt = 0;
  }

  long mInt;
}
