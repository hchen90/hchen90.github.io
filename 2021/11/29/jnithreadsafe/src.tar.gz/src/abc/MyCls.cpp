#include <iostream>
#include <mutex>
#include <cassert>

#include "MyCls.h"

std::mutex mu_thread_safe;

/*
 * Class:     MyCls
 * Method:    sayHello
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_MyCls_sayHello
  (JNIEnv *, jclass) {
    std::cout << "hello" << std::endl;
  }

/*
 * Class:     MyCls
 * Method:    threadSafe
 * Signature: (LConSt;)V
 */
JNIEXPORT void JNICALL Java_MyCls_threadSafe
  (JNIEnv *env, jclass clz, jobject cons_st) {
    // -- 1 -- 使用C++的互斥锁来阻塞操作，这样可以保证线程安全
    jfieldID _fieldId = env->GetStaticFieldID(clz, "mySafeInt", "J"); // 获得类中的静态成员变量

    mu_thread_safe.lock();
    env->SetStaticLongField(clz, _fieldId, 12345); // 这里通过互斥锁来达到线程安全
    mu_thread_safe.unlock();

    // -- 2 -- 通过形式参数形式传递变量进入，只要保证形参不同即可线程安全
    jclass _cs_clz = env->FindClass("ConSt");
    assert(_cs_clz != nullptr);
    jfieldID _cs_fieldId = env->GetFieldID(_cs_clz, "mInt", "J");
    env->SetLongField(cons_st, _cs_fieldId, 12345);
  }

/*
 * Class:     MyCls
 * Method:    threadUnsafe
 * Signature: ()V
 */
JNIEXPORT jint JNICALL Java_MyCls_threadUnsafe
  (JNIEnv *, jclass) {
    // -- 3 -- 在C++层存储公共数据，并进行改写不加锁，不是线程安全的
    static int _unsafe_int = 0;
    _unsafe_int++; // 这里不加任何互斥锁机制
    return _unsafe_int;
  }

/*
 * Class:     MyCls
 * Method:    threadUnsafe2
 * Signature: ()V
 */
JNIEXPORT void JNICALL Java_MyCls_threadUnsafe2
  (JNIEnv *env, jobject obj) {
    // -- 4 -- 或者C++层操作的公共数据是在java层的变量，亦不加锁，也不是线程安全的
    jclass _clz = env->FindClass("MyCls");
    assert(_clz != nullptr);
    jfieldID fieldId = env->GetFieldID(_clz, "myUnsafeInt", "J");
    assert(fieldId != nullptr);
    jlong myUnsafeInt = env->GetLongField(obj, fieldId) + 1;
    env->SetLongField(obj, fieldId, myUnsafeInt);
  }

