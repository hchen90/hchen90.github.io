import java.lang.String;
import java.lang.System;

class MyCls {
  public static void main(String[] args) {
    if (loadLibrary()) {
      sayHello();

      ConSt st = new ConSt();

      threadSafe(st); // 只要传进的st唯一即可达到线程安全的要求

      System.out.println(mySafeInt);
      System.out.println(st.mInt);

      System.out.printf("unsafe int:%d\n", threadUnsafe());

      MyCls obj = new MyCls();
      obj.threadUnsafe2();
      System.out.printf("unsafe int:%d\n", obj.myUnsafeInt);
    }
  }

  // 加载c动态库
  private static boolean loadLibrary() {
    try {
      System.loadLibrary("abc");
    } catch(SecurityException e) {
      e.printStackTrace();
      return false;
    } catch(UnsatisfiedLinkError e) {
      e.printStackTrace();
      return false;
    }
    return true;
  }

  private static long mySafeInt = 0;
  private long myUnsafeInt = 0;

  // 本地化接口
  private static native void sayHello();
  private static native void threadSafe(ConSt st);
  private static native int threadUnsafe(); // 使用了C++层的公共变量，且没有加锁机制
  private native void threadUnsafe2(); // 使用了Java层的公共变量，且没有加锁机制
}