环境：
  Linux + OpenJDK11

1. 生成C++头文件
  javac -cp . -h abc MyCls.java
2. 编译C++动态库
  mkdir -p abc/build && cd abc/build && cmake .. && make
3. 运行java程序
  javac MyCls.java ConSt.java && LD_LIBRARY_PATH=abc/build java -cp . MyCls

注：以上三个步骤都是在src目录开始
